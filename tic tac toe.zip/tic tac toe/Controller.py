from turtle import Turtle
turn=1
def draw_circle(x,y):
    c=Turtle()
    c.penup()
    c.hideturtle()
    c.goto(x,y-30)
    c.color("red")
    c.width(5)
    c.pendown()
    c.circle(30)
    c.penup()
def draw_x( xc, y):
    x=Turtle()
    x.penup()
    x.hideturtle()
    x.goto(xc-20,y+20)
    x.pendown()
    x.color("green")
    x.width(5)
    x.right(45)
    x.forward(60)
    x.backward(30)
    x.left(90)
    x.forward(30)
    x.backward(60)
    x.right(45)
def column(i):
    if i > -150 and i < -50:
        return 0
    elif i > -50 and i < 50:
        return 1
    elif i > 50 and i < 150:
        return 2
    else:
        return None

def row(j):
    if j > -150 and j < -50:
        return 2
    elif j > -50 and j < 50:
        return 1
    elif j > 50 and j < 150:
        return 0
    else:
        return None

