from turtle import Turtle, Screen
from Controller import row, column, draw_circle, draw_x
from Model import check_winner

screen = Screen()
screen.screensize()
screen.bgcolor("black")
screen.tracer(0)  # Disable automatic updates

T = Turtle()
turn = 1
message = Turtle()
message.hideturtle()
message.penup()
message.color("black")
message.goto(0, 0)
message.hideturtle()

game_board = [
    [None, None, None],
    [None, None, None],
    [None, None, None]
]

def draw_grid():
    t = Turtle()
    t.speed(0)
    t.penup()
    t.color("white")
    x = -150
    y = -150
    t.goto(x, y)
    t.pendown()
    for _ in range(4):
        t.forward(300)
        t.left(90)
    for i in range(0, 2):
        y += 100
        t.penup()
        t.goto(x, y)
        t.pendown()
        t.forward(300)
    t.setheading(270)
    y = 150
    for i in range(0, 2):
        x += 100
        t.penup()
        t.goto(x, y)
        t.pendown()
        t.forward(300)
    t.hideturtle()
    screen.tracer(1)
    screen.tracer(0)

draw_grid()

def onMouseClick(x, y):
    col = column(x)
    r = row(y)
    if col is not None and r is not None:
        cell_x = -150 + col * 100 + 50
        cell_y = 150 - r * 100 - 50
        global turn
        if game_board[r][col] is None:
            game_board[r][col] = turn
            if turn == 1:
                turn = 2
                draw_x(cell_x, cell_y)
            elif turn == 2:
                turn = 1
                draw_circle(cell_x, cell_y)
        winner = check_winner(game_board)
        if winner is not None:
            screen.clear()
            message.write("Player {} wins!".format(winner), align="center", font=("Arial", 24, "normal"))
        screen.update()  # Force the window to update

screen.onclick(onMouseClick)
screen.listen()
screen.mainloop()
