from turtle import Turtle
def check_winner(board):
    for row in board:
        if all(cell == row[0] and cell is not None for cell in row):
            return row[0]
    for col in range(3):
        if all(row[col] == board[0][col] and board[0][col] is not None for row in board):
            return board[0][col]
    if all(board[i][i] == board[0][0] and board[i][i] is not None for i in range(3)):
        return board[0][0]

    if all(board[i][2 - i] == board[0][2] and board[i][2 - i] is not None for i in range(3)):
        return board[0][2]

    return None